import React from "react";
export default function DynamicField() {
  const [field, setField] = React.useState([]);

  const addField = () => {
    setField((prevState) => [...prevState, { qualification: "" }]);
  };

  const removeField = (index) => {
    let remField = [...field];
    remField.splice(index, 1);
    setField(remField);
  };

  function handleChangeDynamic(index, event) {
    console.log(index, event);
    const { name, value } = event.target;
    setField[index]({
      ...field, 
      [name]: value,
    });
  }

  return (
    <div className="dynamicInput">
      <div className="addButtion">
        <label htmlFor="">Qualifications</label>
        <button onClick={addField}>+</button>
        {field.length > 0 && <button onClick={removeField}>-</button>}
      </div>

      {field.map((form, index) => {
        return (
          <div key={index}>
            <input
              className="qualification-input"
              type="text"
              name="qualification"
              value={form.qualification}
              onChange={(event) => handleChangeDynamic(index, event)}
            />
          </div>
        );
      })}
    </div>
  );
}
